<div id="loading-area" style=""></div>
        <section id="Slider">
        <style>
            :root {
                --primary: #00568d;
            }

            .hero_shape_wrapper .shape {
                z-index: 1 !important;
            }
        </style>
        <section class="position-relative style_2 overflow-hidden" style="background: linear-gradient(84deg,rgb(21 200 235 / 10%) 20%,rgb(245 245 245) 80%);">
            <div class="hero_shape_wrapper">
                <img class="img-fluid shape shape1" loading="lazy" src="{{ url('build/images/Content/img/ssl/1.png')}}" alt="shape" />
                <img class="img-fluid shape shape2" loading="lazy" src="{{ url('build/images/Content/img/ssl/2.png')}}" alt="shape" />
                <img class="img-fluid shape shape3" loading="lazy" src="{{ url('build/images/Content/img/ssl/3.png')}}" alt="shape" />
                <img class="img-fluid shape shape4" loading="lazy" src="{{ url('build/images/Content/img/ssl/4.png')}}" alt="shape" />
                <img class="img-fluid shape shape5" loading="lazy" src="{{ url('build/images/Content/img/ssl/5.png')}}" alt="shape" />
                <img class="img-fluid shape shape6" loading="lazy" src="{{ url('build/images/Content/img/ssl/6.png')}}" alt="shape" />
                <img class="img-fluid shape shape7" loading="lazy" src="{{ url('build/images/Content/img/ssl/7.png')}}" alt="shape" />
                <img class="img-fluid shape shape8" loading="lazy" src="{{ url('build/images/Content/img/ssl/8.png')}}" alt="shape" />
                <img class="img-fluid shape shape9" loading="lazy" src="{{ url('build/images/Content/img/ssl/9.png')}}" alt="shape" />
                <img class="img-fluid shape shape10" loading="lazy" src="{{ url('build/images/Content/img/ssl/10.png')}}" alt="shape" />
                <img class="img-fluid shape shape11" loading="lazy" src="{{ url('build/images/Content/img/ssl/11.png')}}" alt="shape" />
            </div>
            
    