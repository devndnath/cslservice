<!DOCTYPE html>
<html lang="en-US">


<!-- Mirrored from globalinformatics.com.bd/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 12 Feb 2025 04:41:02 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <title>CSL Service </title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta property="og:image" content="">
    <link rel="icon" href="{{ url('build/assets/images/logo/cslservice.jpg')}}" type="image/x-icon" sizes="64x64">

    <link rel="stylesheet" href="{{ url('build/assets/css/npm/boxicons.min.css') }}" media="print" onload="this.media='screen'">
    <link rel="stylesheet" href="{{ url('build/Theme/css/lib.css') }}" >
    <link rel="stylesheet" href="{{ url('build/assets/css/style.css') }}" >
    <link rel="stylesheet" href="{{ url('build/assets/flaticons/gil-icon/gil-icon.css') }}" >
    <link rel="stylesheet" href="{{ url('build/assets/flaticons/MegaMenuIcons/n-icon.css') }}" >
    <link rel="stylesheet" href="{{ url('build/assets/css/MegaMenu.css') }}" >
    <link rel="stylesheet" href="{{ url('build/assets/css/font-awesome/4.7.0/css/font-awesome.min.css') }}" >
    <link rel="stylesheet" href="{{ url('build/assets/css/animate.compat.css') }}" >
    <link rel="stylesheet" href="{{ url('build/assets/css/custom.css') }}" >
    <link rel="stylesheet" href="{{ url('build/assets/css/aos.css') }}" />
    <script src="{{ url('build/assets/js/jquery-3.6.0.min.js') }}" ></script>
    <script src="{{ url('build/assets/js/aos.js') }}"></script>
</head>

<body>